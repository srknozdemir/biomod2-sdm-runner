Ekran goruntulerini bu klasore koyun ve ana README.md icindeki
yorum satirini asagidaki gibi degistirin:

![Interface](images/screenshot.png)
