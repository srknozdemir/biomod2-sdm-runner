---
name: Bug report
about: Report a problem with a model run
---

**What happened**

**What you expected**

**Configuration**
- Response type:
- Algorithms selected:
- Operating system:
- R version:
- biomod2 version:

**Logs**
Please attach or paste:
- `runs/<run_id>/progress.log`
- `results/<run_id>/sessionInfo.txt`
